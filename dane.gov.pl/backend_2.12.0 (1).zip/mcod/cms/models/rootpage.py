# -*- coding: utf-8 -*-
from wagtail.admin.edit_handlers import StreamFieldPanel
from wagtail.api import APIField
from wagtail.api.v2.serializers import StreamField as StreamFieldSerializer
from wagtail.core.fields import StreamField

from mcod.cms.blocks.common import CarouselBlock
from mcod.cms.models.base import BasePage


class RootPage(BasePage):
    over_login_section_cb = StreamField(CarouselBlock(max_num=5, required=False), default=None, blank=True,
                                        verbose_name='Blok nad paskiem logowania',
                                        help_text='TODO: napisać'
                                        )
    over_search_field_cb = StreamField(CarouselBlock(max_num=5, required=False), default=None, blank=True,
                                       verbose_name='Blok pod wyszukiwarką',
                                       help_text='TODO: napisać'
                                       )
    over_latest_news_cb = StreamField(CarouselBlock(max_num=5, required=False), default=None, blank=True,
                                      verbose_name='Blok nad sekcją "Aktualności"',
                                      help_text='TODO: napisać'
                                      )
    over_login_section_cb_en = StreamField(CarouselBlock(max_num=5, required=False), default=None, blank=True,
                                           verbose_name='Blok nad paskiem logowania',
                                           help_text='TODO: napisać'
                                           )
    over_search_field_cb_en = StreamField(CarouselBlock(max_num=5, required=False), default=None, blank=True,
                                          verbose_name='Blok pod wyszukiwarką',
                                          help_text='TODO: napisać'
                                          )
    over_latest_news_cb_en = StreamField(CarouselBlock(max_num=5, required=False), default=None, blank=True,
                                         verbose_name='Blok nad sekcją "Aktualności"',
                                         help_text='TODO: napisać'
                                         )

    parent_page_types = ['wagtailcore.Page']

    fixed_url_path = ''

    api_fields = BasePage.api_fields + [
        APIField('over_login_section_cb', serializer=StreamFieldSerializer(source='over_login_section_cb_i18n')),
        APIField('over_search_field_cb', serializer=StreamFieldSerializer(source='over_search_field_cb_i18n')),
        APIField('over_latest_news_cb', serializer=StreamFieldSerializer(source='over_latest_news_cb_i18n')),
    ]

    content_panels_pl = BasePage.content_panels_pl + [
        StreamFieldPanel('over_login_section_cb'),
        StreamFieldPanel('over_search_field_cb'),
        StreamFieldPanel('over_latest_news_cb'),
    ]

    content_panels_en = BasePage.content_panels_en + [
        StreamFieldPanel('over_login_section_cb_en'),
        StreamFieldPanel('over_search_field_cb_en'),
        StreamFieldPanel('over_latest_news_cb_en'),
    ]

    i18n_fields = BasePage.i18n_fields + ['over_login_section_cb', 'over_search_field_cb', 'over_latest_news_cb']

    class Meta:
        verbose_name = "Strona główna"
        verbose_name_plural = "Strony główne"

    def copy_pl_to_en(self):
        super().copy_pl_to_en()
        self.over_login_section_cb_en = self.over_login_section_cb
        self.over_search_field_cb_en = self.over_search_field_cb
        self.over_latest_news_cb_en = self.over_latest_news_cb
