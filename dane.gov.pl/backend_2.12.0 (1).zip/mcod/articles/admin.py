from django.conf import settings
from django.contrib import admin
from django.utils.safestring import mark_safe
from django.utils.text import slugify
from django.utils.translation import gettext_lazy as _, get_language

from mcod.articles.forms import ArticleForm
from mcod.articles.models import Article, ArticleTrash
from mcod.lib.admin_mixins import (
    TrashMixin, HistoryMixin, LangFieldsOnlyMixin,
    SoftDeleteMixin, CreatedByDisplayAdminMixin, StatusLabelAdminMixin,
    DynamicAdminListDisplayMixin, MCODAdminMixin
)
from mcod.unleash import is_enabled


@admin.register(Article)
class ArticleAdmin(DynamicAdminListDisplayMixin, CreatedByDisplayAdminMixin, StatusLabelAdminMixin, SoftDeleteMixin,
                   HistoryMixin, LangFieldsOnlyMixin, MCODAdminMixin, admin.ModelAdmin):
    actions_on_top = True
    autocomplete_fields = ['tags']
    prepopulated_fields = {"slug": ("title",)}
    fieldsets = (
        (
            None,
            {
                'classes': ('suit-tab', 'suit-tab-general',),
                'fields': (
                    "preview_link",
                    "title",
                )
            }
        ),

        (
            'url',
            {
                'classes': ('collapse', 'suit-tab', 'suit-tab-general',),
                'fields': (
                    "slug",
                )
            }
        ),

        (
            None,
            {
                'classes': ('suit-tab', 'suit-tab-general',),
                'fields': (
                    "notes",
                    'author',
                    'license',
                    'status',
                    'category'
                )
            }
        ),

    )
    readonly_fields = ['preview_link']
    suit_form_tabs = (
        ('general', _('General')),
        *LangFieldsOnlyMixin.get_translations_tabs(),
        ('tags', _('Tags')),
    )

    list_display = [
        "title",
        "status",
        "created_by",
        'category',
        'preview_link',
        'obj_history'
    ]
    list_filter = ['category', ]
    search_fields = ["title", "created_by__email"]
    form = ArticleForm

    def get_fieldsets(self, request, obj=None):
        if is_enabled('S18_new_tags.be'):
            tags_tab_fields = ('tags_pl', 'tags_en')
        else:
            tags_tab_fields = ('tags', )

        tags_fieldset = (
            (
                _("Tags"),
                {
                    'classes': ('suit-tab', 'suit-tab-tags',),
                    'fields': tags_tab_fields,
                }
            ),
        )
        return self.fieldsets + tags_fieldset + tuple(self.get_translations_fieldsets())

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        if is_enabled('S18_new_tags.be'):
            form.recreate_tags_widgets(request=request, db_field=Article.tags.field, admin_site=self.admin_site)
        return form

    def get_queryset(self, request):
        qs = Article.objects.all()
        self.request = request
        return qs

    def preview_link(self, obj):
        url = f"{settings.BASE_URL}/{get_language()}/knowledge-base/preview/{obj.id}"
        return mark_safe('<a href="%s" class="btn" target="_blank">%s</a>' % (url, _("Preview")))

    preview_link.allow_tags = True
    preview_link.short_description = _("Preview link")

    def save_model(self, request, obj, form, change):
        if 'slug' in form.cleaned_data:
            if form.cleaned_data['slug'] == "":
                obj.slug = slugify(form.cleaned_data['title'])
        if not obj.id:
            obj.created_by = request.user
        obj.modified_by = request.user
        obj.save()

    class Media:
        js = ("articles/js/hide_license_buttons.js",)


@admin.register(ArticleTrash)
class ArticleTrashAdmin(TrashMixin):
    list_display = ['title', 'author']
    search_fields = ['title', 'author']

    if is_enabled('S18_new_tags.be'):
        tags_fields = ('tags_list_pl', 'tags_list_en')
    else:
        tags_fields = ('tags',)

    fields = [
        'title',
        'author',
        'datasets',
        'notes',
        'slug',
        'status',
        *tags_fields,
        'license_id',
        'is_removed'
    ]
    readonly_fields = [
        'title',
        'author',
        'datasets',
        'notes',
        'slug',
        'status',
        *tags_fields,
        'license_id'
    ]

    def tags_list_pl(self, instance):
        return instance.tags_as_str(lang='pl')
    tags_list_pl.short_description = _('Tags') + ' (PL)'

    def tags_list_en(self, instance):
        return instance.tags_as_str(lang='en')
    tags_list_en.short_description = _('Tags') + ' (EN)'

# @admin.register(ArticleCategory)
# class ArticleCategoryAdmin(LangFieldsOnlyMixin, admin.ModelAdmin):
#     list_display = ['name', 'description', 'id']
#     ordering = ('id', )
#
#     fieldsets = [
#         (None, {
#             'classes': ('suit-tab', 'suit-tab-general',),
#             'fields': [
#                 'name_pl', 'description_pl'
#             ]
#         }),
#         (None, {
#             'classes': ('suit-tab', 'suit-tab-english',),
#             'fields': ['name_en', 'description_en', ]
#         }),
#
#     ]
#
#     suit_form_tabs = (
#         ('general', _('General')),
#         ('english', _('Translation (EN)'))
#     )
