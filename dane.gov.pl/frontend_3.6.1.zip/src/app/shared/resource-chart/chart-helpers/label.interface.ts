export type Label = string;
